import java.math.BigInteger;

class Node implements Comparable<Node>{
    private String key;
    private BigInteger val;
    private int num;

    String getKey() {
        return key;
    }

    void setKey(String key) {
        this.key = key;
    }

    BigInteger getVal() {
        return val;
    }

    void setVal(BigInteger val) {
        this.val = val;
    }

    int getNum() {
        return num;
    }

    void setNum(int num) {
        this.num = num;
    }

    @Override
    public int compareTo(Node a) {
        if(this.num-a.num != 0){
            return a.num-this.num;
        }
        else if(!a.val.subtract(this.val).equals(BigInteger.valueOf(0))) {
            BigInteger l = a.val.subtract(this.val);
            String ls = l.toString();
            return Integer.parseInt(ls);
        }
        else{
            char[] chars1=a.key.toCharArray();
            char[] chars2=this.key.toCharArray();
            int i=0;
            while(i<chars1.length && i<chars2.length){
                if(chars1[i]<chars2[i]){
                    return 1;
                }else if(chars1[i]>chars2[i]){
                    return -1;
                }else{
                    i++;
                }
            }
            if(i==chars1.length){  //o1到头
                return 1;
            }
            if(i== chars2.length){ //o2到头
                return -1;
            }
            return 0;
        }
    }

    @Override
    public String toString() {
        return
            "key='" + key + '\'' +
            ", val=" + val +
            ", num=" + num +
            ';'+"\n";
    }


}