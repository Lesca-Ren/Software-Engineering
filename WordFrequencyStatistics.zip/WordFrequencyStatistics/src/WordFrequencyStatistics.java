import java.io.*;
import java.math.BigInteger;
import java.util.*;

import static java.math.BigInteger.*;

public class WordFrequencyStatistics{

    private static S [] x;
    private static Node[] res;
    private static String [] stopwords;
    private static int stopWordsLength;
    private static StringBuffer stringBuffer;

//    public static void main(String[] args) {
//        stringBuffer = new StringBuffer();
//        res = new Node[20004];
//        for(int i=0;i<=20000;i++){
//            res[i] = new Node();
//        }
//        if(Arrays.asList(args).contains("-f")){
//            long startTime=System.nanoTime();   //获取开始时间
//            String s=args[1];
//            function1(readFile(s));
//            long endTime=System.nanoTime(); //获取结束时间
//            System.out.println("程序运行时间： "+(endTime-startTime)+"ns");
//        }else if(Arrays.asList(args).contains("-d")){
//            long startTime=System.nanoTime();   //获取开始时间
//            if(Arrays.asList(args).contains("-s")){
//                ArrayList<String> listFileName = new ArrayList<>();
//                getAllFileName(args[1],listFileName);
//                for(String name:listFileName){
//                    System.out.println(name);
//                }
//            }else{
//                ArrayList<String> listFileName = new ArrayList<>();
//                getAllFileName(args[1],listFileName);
//                for(String name:listFileName){
//                    if(name.contains(".txt")){
//                        function1(readFile(name));
//                    }
//                }
//            }
//            long endTime=System.nanoTime(); //获取结束时间
//            System.out.println("程序运行时间： "+(endTime-startTime)+"ns");
//        }else if(Arrays.asList(args).contains("-c")){
//            long startTime=System.nanoTime();   //获取开始时间
//            x=new S[600];
//            String s=args[1];
//            readFile0(s);
//            long endTime=System.nanoTime(); //获取结束时间
//            System.out.println("程序运行时间： "+(endTime-startTime)+"ns");
//        }else if(Arrays.asList(args).contains("-n")){
//            long startTime=System.nanoTime();   //获取开始时间
//            String s=args[2];
//            function2(readFile(s),Integer.parseInt(args[1]));
//            long endTime=System.nanoTime(); //获取结束时间
//            System.out.println("程序运行时间： "+(endTime-startTime)+"ns");
//        }else if(Arrays.asList(args).contains("-x")){
//            long startTime=System.nanoTime();   //获取开始时间
//            String s=args[1];
//            function3(readFile(s));
//            String s1=args[3];
//            function1(readFile(s1));
//            long endTime=System.nanoTime(); //获取结束时间
//            System.out.println("程序运行时间： "+(endTime-startTime)+"ns");
//        }else if(Arrays.asList(args).contains("-p")){
//            long startTime=System.nanoTime();   //获取开始时间
//            String s=args[2];
//            function4(readFile1(s),Integer.parseInt(args[1]));
//            long endTime=System.nanoTime(); //获取结束时间
//            System.out.println("程序运行时间： "+(endTime-startTime)+"ns");
//            return;
//        }
//        String outputFilePath = "/E:/soft-engerneering/demo01/fourth step/data/text.txt";
//        outputfile(outputFilePath,stringBufferDataProcessing());
//    }

    private static StringBuffer stringBufferDataProcessing() {
        String str3 = stringBuffer.toString();
        String [] str4 = str3.split("\\r?\\n");
        int str1=0;
        for (String line : str4) {
            int kstart = line.indexOf("key=");
            int kiend = line.indexOf("'",kstart+5);
            res[str1].setKey(line.substring(kstart+5,kiend));

            int valstart = line.indexOf("val=");
            int valend = line.indexOf(",",valstart+4);
            BigInteger val = new BigInteger(line.substring(valstart+4,valend),10);
            res[str1].setVal(val);

            int numstart = line.indexOf("num=");
            int numend = line.indexOf(";",numstart+4);
            BigInteger num = new BigInteger(line.substring(numstart+4,numend),10);
            res[str1].setNum(num);
            str1++;
        }

        stringBuffer=new StringBuffer();
        StringBuffer bigStringBuffer = new StringBuffer();
        for(int i=0;i<str1;i++){
            int flag = res[i].getVal().compareTo(BigInteger.valueOf(2000000000));
            if(flag < 0){
                stringBuffer.append(res[i].toString());
            }
            else{
                bigStringBuffer.append(res[i].toString());
            }
        }

        //解析频次小于整数范围的数据，并排序
        String str31 = stringBuffer.toString();
        String [] str41 = str31.split("\\r?\\n");
        int str11=0;
        for (String line : str41) {
            int kstart = line.indexOf("key=");
            int kiend = line.indexOf("'",kstart+5);
            res[str11].setKey(line.substring(kstart+5,kiend));

            int valstart = line.indexOf("val=");
            int valend = line.indexOf(",",valstart+4);
            BigInteger val = new BigInteger(line.substring(valstart+4,valend),10);
            res[str11].setVal(val);

            int numstart = line.indexOf("num=");
            int numend = line.indexOf(";",numstart+4);
            BigInteger num = new BigInteger(line.substring(numstart+4,numend),10);
            res[str11].setNum(num);
            str11++;
        }
        Arrays.sort(res,0,str11);

        stringBuffer=new StringBuffer();

        for(int i=0;i<str11;i++){
            stringBuffer.append(res[i].toString());
        }


        return bigStringBuffer;
    }

    private static void outputfile(String outputFilePath, StringBuffer strbuffer) {
        FileWriter fw = null;
        FileWriter bigfw =null;
        try {
            //如果文件存在，则追加内容；如果文件不存在，则创建文件
            File f=new File(outputFilePath);
            fw = new FileWriter(f, true);

            File bigf=new File("/E:/soft-engerneering/demo01/fourth step/data/bigtext.txt");
            bigfw = new FileWriter(bigf, true);

        } catch (IOException e) {
            e.printStackTrace();
        }
        PrintWriter pw = null;
        if (fw != null) {
            pw = new PrintWriter(fw);
        }
        if (pw != null) {
            pw.println(stringBuffer);
        }
        if (pw != null) {
            pw.flush();
        }

        PrintWriter bigpw = null;
        if (bigfw != null) {
            bigpw = new PrintWriter(bigfw);
        }
        if (bigpw != null) {
            bigpw.println(strbuffer);
        }
        if (bigpw != null) {
            bigpw.flush();
        }
        try {
            if (fw != null) {
                fw.flush();
            }
            if (pw != null) {
                pw.close();
            }
            if (fw != null) {
                fw.close();
            }

            if (bigfw != null) {
                bigfw.flush();
            }
            if (bigpw != null) {
                bigpw.close();
            }
            if (bigpw != null) {
                bigpw.close();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

//    private static void listAll(File dir, int level){
//        System.out.println(getSpace(level)+dir.getName());
//        level++;//每调用一次，level加1
//        File[] files=dir.listFiles();//获取指定目录下当前的所有文件夹或者文件对象
//        for(int x=0;x<files.length;x++){
//            if(files[x].isDirectory()){
//                listAll(files[x], level);
//            }else{
//                System.out.println(getSpace(level)+files[x].getName());
//            }
//        }
//
//    }

//    private static String getSpace(int level){
//        StringBuilder sb = new StringBuilder();
//        sb.append("|--");
//        for(int x= 0;x<level;x++){
//            sb.insert(0,"|  ");
//        }
//        return sb.toString();
//    }

    private static void readFile0(String arg) {
        int count = 0;
        for(int i=1;i<=100;i++){
            x[i]=new S(i,0,0);
        }
        try (FileReader reader = new FileReader(arg);
             BufferedReader br = new BufferedReader(reader)
        ) {
            String line;
            while ((line = br.readLine()) != null) {
                // 一次读入一行数据
                System.out.println(line);
                int [] y=new int[600];
                for(int i=1;i<=26;i++){
                    y[i]=0;
                }
                char [] c;int len=line.length();
                System.out.println(len);
                c=line.toCharArray();
                for(int i=0;i<len;i++){
                    if((c[i]>='a'&& c[i]<='z') || (c[i]>='A' && c[i]<='Z')){
                        count++;
                        switch (c[i]) {
                            case 'a':
                                y[1]++;
                                break;
                            case 'b':
                                y[2]++;
                                break;
                            case 'c':
                                y[3]++;
                                break;
                            case 'd':
                                y[4]++;
                                break;
                            case 'e':
                                y[5]++;
                                break;
                            case 'f':
                                y[6]++;
                                break;
                            case 'g':
                                y[7]++;
                                break;
                            case 'h':
                                y[8]++;
                                break;
                            case 'i':
                                y[9]++;
                                break;
                            case 'j':
                                y[10]++;
                                break;
                            case 'k':
                                y[11]++;
                                break;
                            case 'l':
                                y[12]++;
                                break;
                            case 'm':
                                y[13]++;
                                break;
                            case 'n':
                                y[14]++;
                                break;
                            case 'o':
                                y[15]++;
                                break;
                            case 'p':
                                y[16]++;
                                break;
                            case 'q':
                                y[17]++;
                                break;
                            case 'r':
                                y[18]++;
                                break;
                            case 's':
                                y[19]++;
                                break;
                            case 't':
                                y[20]++;
                                break;
                            case 'u':
                                y[21]++;
                                break;
                            case 'v':
                                y[22]++;
                                break;
                            case 'w':
                                y[23]++;
                                break;
                            case 'x':
                                y[24]++;
                                break;
                            case 'y':
                                y[25]++;
                                break;
                            case 'z':
                                y[26]++;
                                break;
                            case 'A':
                                y[1]++;
                                break;
                            case 'B':
                                y[2]++;
                                break;
                            case 'C':
                                y[3]++;
                                break;
                            case 'D':
                                y[4]++;
                                break;
                            case 'E':
                                y[5]++;
                                break;
                            case 'F':
                                y[6]++;
                                break;
                            case 'G':
                                y[7]++;
                                break;
                            case 'H':
                                y[8]++;
                                break;
                            case 'I':
                                y[9]++;
                                break;
                            case 'J':
                                y[10]++;
                                break;
                            case 'K':
                                y[11]++;
                                break;
                            case 'L':
                                y[12]++;
                                break;
                            case 'M':
                                y[13]++;
                                break;
                            case 'N':
                                y[14]++;
                                break;
                            case 'O':
                                y[15]++;
                                break;
                            case 'P':
                                y[16]++;
                                break;
                            case 'Q':
                                y[17]++;
                                break;
                            case 'R':
                                y[18]++;
                                break;
                            case 'S':
                                y[19]++;
                                break;
                            case 'T':
                                y[20]++;
                                break;
                            case 'U':
                                y[21]++;
                                break;
                            case 'V':
                                y[22]++;
                                break;
                            case 'W':
                                y[23]++;
                                break;
                            case 'X':
                                y[24]++;
                                break;
                            case 'Y':
                                y[25]++;
                                break;
                            case 'Z':
                                y[26]++;
                                break;

                        }
                    }
                }
                for(int i=1;i<=26;i++){
                    x[i].setCnt(x[i].getCnt()+y[i]);
                }
            }
            for(int i=1;i<=26;i++){
                x[i].setValue(100*x[i].getCnt()*1.0/ count);
            }
            Arrays.sort(x, 1, 26);

            for(int i=1;i<=26;i++){
                System.out.printf("%c ", x[i].getIndex()+'a'-1);
                System.out.printf("%.2f%% %d\n",x[i].getValue(),x[i].getCnt());
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private static HashMap<String,BigInteger> readFile1(String args) {
        HashMap<String,BigInteger> hm = new HashMap<>();
        try (FileReader reader = new FileReader(args)) {
            try (BufferedReader br = new BufferedReader(reader)) {
                String line;
                while ((line = br.readLine()) != null) {
                    String str = line.toLowerCase();
                    String str1;
                    for (int i = 0; i < str.length(); i++) {
                        if (Character.isLetter(str.charAt(i))) {
                            int begin = i;
                            i++;
                            while ((i < str.length()) && (Character.isLetter(str.charAt(i)) || Character.isDigit(str.charAt(i)))) {
                                i++;
                            }
                            while (i < str.length() - 1 && str.charAt(i) == ' ' && Character.isLetter(str.charAt(i + 1))) {
                                i++;
                                while ((i < str.length()) && (Character.isLetter(str.charAt(i)) || Character.isDigit(str.charAt(i)))) {
                                    i++;
                                }
                            }
                            i--;
                            str1 = str.substring(begin, i + 1);
                            if (!(hm.containsKey(str1))) {
                                hm.put(str1, BigInteger.valueOf(1));
                            } else {
                                BigInteger value = hm.get(str1).add(BigInteger.valueOf(1));
                                hm.put(str1, value);
                            }
                        }
                    }
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return hm;
    }

    private static HashMap<String,BigInteger> readFile(String args) {
        HashMap<String,BigInteger> hm = new HashMap<>();
        try (FileReader reader = new FileReader(args);
             BufferedReader br = new BufferedReader(reader)
        ) {
            String line;
            while ((line = br.readLine()) != null) {
                String str = line.toLowerCase();
                String str1;
                for(int i=0;i<str.length();i++){
                    if(Character.isLetter(str.charAt(i))){
                        int begin = i;
                        i++;
                        while((i<str.length()) &&  (Character.isLetter(str.charAt(i)) || Character.isDigit(str.charAt(i))) ){
                            i++;
                        }
                        i--;
                        str1=str.substring(begin,i+1);
                        if(!(hm.containsKey(str1))){
                            hm.put(str1, valueOf(1));
                        }else{
                            BigInteger value=hm.get(str1).add(valueOf(1));
                            hm.put(str1, value);
                        }
                    }
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return hm;
    }

    private static boolean findStopWords(String t){
        // System.out.println(stopWordsLength);
        for(int i = 0;i<stopWordsLength;i++){
            // System.out.println(stopwords[i].equals(t));
            if(stopwords[i].equals(t)){
                return true;
            }
        }
        return false;
    }

    private static void getAllFileName(String path, ArrayList<String> listFileName){
        File file = new File(path);
        File [] files = file.listFiles();
        String [] names = file.list();
        if(names != null){
            String [] completNames = new String[names.length];
            for(int i=0;i<names.length;i++){
                completNames[i]=path+"/"+names[i];
            }
            listFileName.addAll(Arrays.asList(completNames));
        }
        assert files != null;
        for(File a:files){
            if(a.isDirectory()){//如果文件夹下有子文件夹，获取子文件夹下的所有文件全路径。
                getAllFileName(a.getAbsolutePath()+"/",listFileName);
            }
        }
    }

    private static void function1(HashMap<String, BigInteger> hm){
        Iterator iter = hm.entrySet().iterator();
        int index=0;
        while (iter.hasNext()) {
            Map.Entry entry = (Map.Entry) iter.next();
            Object key = entry.getKey();
            Object val = entry.getValue();
            if(!(findStopWords(key.toString()))){
                res[index].setKey(key.toString());
                res[index].setVal(BigInteger.valueOf(Long.parseLong(String.valueOf(val))));
                String temp = res[index].getKey();
                BigInteger cnt= BigInteger.valueOf(1);
                for(int i=0;i<temp.length();i++){
                    if(temp.charAt(i)==' '){
                        cnt = cnt.add(BigInteger.valueOf(1));
                    }
                }
                res[index].setNum(cnt);
                index++;
            }
        }
        Arrays.sort(res,0,index);
        for(int i=0;i<index;i++){
            if(stringBuffer.indexOf("'"+res[i].getKey()+"'") == -1){
                stringBuffer.append(res[i].toString());
            }
            else {
                int i1=stringBuffer.indexOf("'"+res[i].getKey()+"'");
                int i2 = stringBuffer.indexOf(";",i1);
                String substr = stringBuffer.substring(i1,i2);
                int subindex = substr.indexOf("val=");
                BigInteger i3 = BigInteger.valueOf(Long.parseLong(substr.substring(subindex+4,subindex+5))).add(res[i].getVal());
                stringBuffer.replace(i1 + subindex + 4, i1+subindex+5,String.valueOf(i3));
            }
        }
    }

    private static void function2(HashMap<String, BigInteger> hm, int n){
        Iterator iter = hm.entrySet().iterator();
        int index=0;
        while (iter.hasNext()) {
            Map.Entry entry = (Map.Entry) iter.next();
            Object key = entry.getKey();
            Object val = entry.getValue();
            res[index].setKey(key.toString());
            res[index].setVal(BigInteger.valueOf((Long)val));
            // System.out.println("key:"+res[index].getKey()+" "+"val:"+res[index].getVal());
            index++;
        }
        Arrays.sort(res,0,index);
        for(int i=0;i<n;i++){
            System.out.println("key:"+res[i].getKey()+" "+"val:"+res[i].getVal());
        }
    }

    private static void function3(HashMap<String, BigInteger> hm){
        Iterator iter = hm.entrySet().iterator();
        int index=0;
        stopwords = new String[2000];
        while (iter.hasNext()) {
            stopwords[index] = "";
            Map.Entry entry = (Map.Entry) iter.next();
            Object key = entry.getKey();
            // System.out.println(key);
            stopwords[index]=key.toString();
            System.out.println("key:"+stopwords[index]);
            index++;
        }
        index--;
        stopWordsLength = index;
    }

    private static void function4(HashMap<String, BigInteger> hm, int n){
        Iterator iter = hm.entrySet().iterator();
        int index=0;
        while (iter.hasNext()) {
            Map.Entry entry = (Map.Entry) iter.next();
            Object key = entry.getKey();
            Object val = entry.getValue();
            // if(!(findStopWords(key.toString()))){
            res[index].setKey(key.toString());
            res[index].setVal(BigInteger.valueOf(Long.parseLong(val.toString())));
            String temp = res[index].getKey();
            BigInteger cnt= BigInteger.valueOf(1);
            for(int i=0;i<temp.length();i++){
                if(temp.charAt(i)==' '){
                    cnt = cnt.add(valueOf(1));
                }
            }
            res[index].setNum(cnt);
            index++;
        }
        Arrays.sort(res,0,index);
        for(int i=0;i<index;i++){
            if(res[i].getNum().equals(n)){
                System.out.println("key:"+res[i].getKey()+" "+"val:"+res[i].getVal()+" num:"+res[i].getNum());
            }
        }
    }
}