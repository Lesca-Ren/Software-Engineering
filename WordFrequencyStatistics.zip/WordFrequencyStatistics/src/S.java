public class S implements Comparable<S>{
    private int index;
    private int cnt;
    private double value;

    S(int index, int cnt, double value){
        this.index=index;
        this.cnt=cnt;
        this.value=value;
    }

    /**
     * @param index the value to set
     */
    public void setIndex(int index) {
        this.index = index;
    }

    /**
     * @param cnt the cnt to set
     */
    void setCnt(int cnt) {
        this.cnt = cnt;
    }

    void setValue(Double value) {
        this.value = value;
    }

    /**
     * @return the index
     */
    int getIndex() {
        return index;
    }

    int getCnt(){
        return cnt;
    }

    /**
     * @return the value
     */
    double getValue() {
        return value;
    }
    @Override
    public int compareTo(S a) {
        if(this.value-a.value != 0)
            return this.cnt-a.cnt;
        else
            return this.index-a.index;
    }

    @Override
    public String toString() {
        return "S{" +
                "index=" + index +
                ", cnt=" + cnt +
                ", value=" + value +
                '}'+"\n";
    }
}